﻿Public Class customers
    Dim id As Integer = Nothing
    Private Sub customers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
        View()
    End Sub
    Private Sub view()
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "Select * from Customers"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
        End Try
    End Sub
    Private Sub DeleteSite(ByRef customer_ID As String)

        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter

            sql = "DELETE * from Customers WHERE customer_ID='" & customer_ID & "'"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox("customer is successfully delted!")

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles DELETE.Click
        If (id <> Nothing) Then
            DeleteSite(id)
            View()

        Else
            MsgBox("Please select any of the sites from the table below!")
        End If

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

        If e.RowIndex >= 0 Then
            Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
            id1.Text = row.Cells(0).Value.ToString
            order1.Text = row.Cells(4).Value.ToString
            name1.Text = row.Cells(1).Value.ToString
            location1.Text = row.Cells(2).Value.ToString
            tel1.Text = row.Cells(3).Value.ToString
            id = CInt(row.Cells(0).Value.ToString)


        End If
    End Sub
    Sub Updatecustomer(ByRef name1 As String, ByRef location1 As String, ByRef tel1 As String, ByRef id1 As String)
        Dim sql As String
        Try
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "UPDATE Customers SET customer_name='" & name1 & "',customer_location='" & location1 & "',customer_tel='" & tel1 & "' WHERE customer_ID='" & id1 & "'"
            'sql = "UPDATE Customers SET customer_name='" & name1 & "',customer_location='" & location1 & "', customer_tel='" & tel1 & "', order ='" & order & "' WHERE customer_ID=" & 4
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox(" customer with this id number" & id1 & " is updated!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub UPDATE_Click(sender As Object, e As EventArgs) Handles UPDATE.Click

        Dim name, location, Telephone As String

        name = name1.Text
        location = location1.Text
        Telephone = tel1.Text
        id = id1.Text
        ' MsgBox(name)
        If (id <> Nothing) Then
            'MsgBox(id)
            Updatecustomer(name, location, Telephone, id)
            view()

        Else
            MsgBox("Please select any of the customer from the table below!")
        End If

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles INSERT.Click
        Try

            Dim customer_ID As String = id1.Text
            Dim customer_name As String = location1.Text
            Dim customer_location As String = location1.Text
            Dim customer_tel As String = tel1.Text
            Dim order As String = order1.Text




            cm = New OleDb.OleDbCommand
            With cm
                .Connection = cn
                .CommandType = CommandType.Text
                .CommandText = "INSERT INTO Customers (customer_ID,customer_name,customer_location,customer_tel,order) VALUES (@MM,@FF,@BB,@GG,@HH)"
                .Parameters.Add(New System.Data.OleDb.OleDbParameter("@MM", System.Data.OleDb.OleDbType.VarChar, 255, customer_ID))
                .Parameters.Add(New System.Data.OleDb.OleDbParameter("@FF", System.Data.OleDb.OleDbType.VarChar, 255, customer_name))
                .Parameters.Add(New System.Data.OleDb.OleDbParameter("@BB", System.Data.OleDb.OleDbType.VarChar, 255, customer_location))
                .Parameters.Add(New System.Data.OleDb.OleDbParameter("@GG", System.Data.OleDb.OleDbType.VarChar, 255, customer_tel))
                .Parameters.Add(New System.Data.OleDb.OleDbParameter("@HH", System.Data.OleDb.OleDbType.VarChar, 255, order))




                ' RUN THE COMMAND
                cm.Parameters("@MM").Value = customer_ID
                cm.Parameters("@FF").Value = customer_name
                cm.Parameters("@BB").Value = customer_location
                cm.Parameters("@GG").Value = customer_tel
                cm.Parameters("@HH").Value = order

                cm.ExecuteNonQuery()
                MsgBox("Record saved.", MsgBoxStyle.Information)


            End With
            view()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub
End Class
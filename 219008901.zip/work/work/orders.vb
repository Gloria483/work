﻿Public Class orders
    Private Sub orders_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call connection()
        View()
    End Sub
    Private Sub view()
        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "Select * from Orders"
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm

            da.Fill(dt)

            DataGridView1.DataSource = dt
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally
        End Try
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)
        name1.Text = row.Cells(1).Value.ToString
        id1.Text = row.Cells(0).Value.ToString
        location1.Text = row.Cells(2).Value.ToString
        'cusid = CInt(row.Cells(0).Value.GetType)

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs)

    End Sub
    Private Sub DeleteSite(ByRef orders_ID As String)

        Try
            Dim sql As String
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter

            sql = "DELETE * from Orders WHERE orders_ID=" & orders_ID & ""
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox("customer is successfully delted!")

        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub


    Sub Updatecustomer(ByRef name1 As String, ByRef id1 As String)
        Dim sql As String
        Try
            cm = New OleDb.OleDbCommand
            Dim dt As New DataTable
            Dim da As New OleDb.OleDbDataAdapter
            sql = "UPDATE Orders SET orders_name='" & name1 & "' WHERE orders_ID=" & id1 & ""
            'sql = "UPDATE Customers SET customer_name='" & name1 & "',customer_location='" & location1 & "', customer_tel='" & tel1 & "', order ='" & order & "' WHERE customer_ID=" & 4
            cm.Connection = cn
            cm.CommandText = sql
            da.SelectCommand = cm
            dr = cm.ExecuteReader
            MsgBox(" customer with this id number" & id1 & " is updated!")
        Catch ex As Exception
            MsgBox(ex.Message)
        Finally

        End Try
    End Sub
    Private Sub UPDATE_Click(sender As Object, e As EventArgs) Handles Update.Click

        Dim name, id As String

        name = name1.Text
        id = id1.Text

        ' MsgBox(name)
        If (id <> Nothing) Then
            'MsgBox(id)
            Updatecustomer(name, id)
            view()

        Else
            MsgBox("Please select any of the customer from the table below!")
        End If
    End Sub
End Class